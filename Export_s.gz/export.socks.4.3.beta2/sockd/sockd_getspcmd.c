/* sockd_getspcmd */

/* >>> Chee-Wai Yeung */
#ifndef NULL
#define NULL	0L
#endif
/* <<< Chee-Wai Yeung */
#include "socks.h"

int sockd_getspcmd(cfAddr, Ncf, no_identd_cmd, bad_id_cmd)
struct config *cfAddr;
int Ncf;
char **no_identd_cmd, **bad_id_cmd;
{
	int i;
	struct config *cp;
	int flags = 0;

#define HAS_NIC 1
#define HAS_BIC 2
#define HAS_BOTH 3

	*no_identd_cmd = NULL;
	*bad_id_cmd = NULL;

	for (i = 0, cp = cfAddr; i++ < Ncf; cp++) {
		if ((cp->action == BAD_ID) && ((flags & HAS_BIC) == 0)) {
			*bad_id_cmd = cp->cmdp;
			if ((flags |= HAS_BIC) == HAS_BOTH)
				return;
		}
		if ((cp->action == NO_IDENTD) && ((flags & HAS_NIC) == 0)) {
			*no_identd_cmd = cp->cmdp;
			if ((flags |= HAS_NIC)== HAS_BOTH)
				return;
		}
	}
}

