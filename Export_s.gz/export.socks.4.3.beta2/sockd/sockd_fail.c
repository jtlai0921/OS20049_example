/* sockd_fail */

#include <sys/types.h>
#include <syslog.h>
#include "socks.h"

void sockd_fail(str, in, ndst, log_msg)
char	*str;
int	in;
Socks_t	*ndst;
char *log_msg;
{
	syslog(LOG_LOW, "failed -- %s.  Error code: %s %m", log_msg, str);
	ndst->cmd = SOCKS_FAIL;
	socks_SendDst(in, ndst);
	exit(1);
}
