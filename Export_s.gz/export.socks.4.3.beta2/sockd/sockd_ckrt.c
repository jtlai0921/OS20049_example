/* sockd_ckrt */

#include <sys/types.h>
#include <stdio.h>
#include <syslog.h>
#include <netinet/in.h>
#include "socks.h"

u_int32 sockd_ckrt(dstshp, rtAddr, Nrt)
struct sockshost_s *dstshp;
struct config *rtAddr;
int Nrt;
{
	
	int i;
	struct config *cp;

	for (i = 0, cp = rtAddr; i++ < Nrt; cp++) {
		if (socks_ckadr(dstshp, cp->ddomain, &cp->daddr, &cp->dmask) == 1) {
			return cp->saddr.s_addr;
		}
	}
	syslog(LOG_LOW, "Cannot find appropriate interface to communicate with %s\n", dstshp->dmname[0]);
	exit(1);
}
