/* make_socksfc */

#include <string.h>
#include <stdio.h>
#include "socks.h"

char *infile = SOCKS_CONF, *outfile = SOCKS_FC;

main(argc, argv)
int argc;
char **argv;
{
	struct config *confAddr = NULL;
	int Nconf = 0;
	int useSyslog = 0;

	if ((argc == 2) || (argc == 3))
		infile = *++argv;
	if (argc == 3)
		outfile = *++argv;
	if (socks_rdconf(infile, &confAddr, &Nconf, useSyslog) == -1) {
		fprintf(stderr, "File  %s not found\n", infile);
		exit(1);
	}
	socks_wrfz(outfile, confAddr, Nconf, useSyslog);
	printf("Frozen configuration written to %s\n", outfile);
}

