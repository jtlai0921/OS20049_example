/* make_sockdfr */

#include <string.h>
#include <stdio.h>
#include "socks.h"

char *infile = SOCKD_ROUTE_FILE, *outfile = SOCKD_FROUTE_FILE;

main(argc, argv)
int argc;
char **argv;
{
	struct config *confAddr = NULL;
	int Nconf = 0;
	int useSyslog = 0;

	if ((argc == 2) || (argc == 3))
		infile = *++argv;
	if (argc == 3)
		outfile = *++argv;
	if (sockd_rdroute(infile, &confAddr, &Nconf, useSyslog) == -1) {
		fprintf(stderr, "File  %s not found\n", infile);
		exit(1);
	}
	socks_wrfz(outfile, confAddr, Nconf, useSyslog);
	printf("Frozen route file written to %s\n", outfile);
}

