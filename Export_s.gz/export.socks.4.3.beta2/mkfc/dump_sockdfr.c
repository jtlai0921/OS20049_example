/* dump_sockdfr */

#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <syslog.h>
#include <netinet/in.h>
#include "socks.h"

/* output sent to stderr */

main(argc, argv)
int argc;
char **argv;
{
	int useSyslog = 0;
	struct config *rtAddr = NULL;
	int Nrt = 0;
	char *rtstrings = NULL;
	char *file = SOCKD_FROUTE_FILE;

	if (argc == 2)
		file = *++argv;
	socks_rdfz(file, &rtAddr, &Nrt, &rtstrings, useSyslog);
	sockd_dumprt(rtAddr, Nrt, useSyslog);
}
