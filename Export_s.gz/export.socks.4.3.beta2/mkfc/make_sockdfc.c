/* make_sockdfc */

#include <string.h>
#include <stdio.h>
#include "socks.h"

char *infile = SOCKD_CONF, *outfile = SOCKD_FC;

main(argc, argv)
int argc;
char **argv;
{
	struct config *confAddr = NULL;
	int Nconf = 0;
	char *ptr1 = NULL, *ptr2 = NULL;
	int useSyslog = 0;

	if ((argc == 2) || (argc == 3))
		infile = *++argv;
	if (argc == 3)
		outfile = *++argv;
	if (sockd_rdconf(infile, &confAddr, &Nconf, &ptr1, &ptr2, useSyslog) == -1) {
		fprintf(stderr, "File  %s not found\n", infile);
		exit(1);
	}
	socks_wrfz(outfile, confAddr, Nconf, useSyslog);
	printf("Frozen configuration written to %s\n", outfile);
}

