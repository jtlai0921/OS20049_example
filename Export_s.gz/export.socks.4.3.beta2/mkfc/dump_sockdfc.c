/* dump_sockdfc */

#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <syslog.h>
#include <netinet/in.h>
#include "socks.h"

/* output sent to stderr */

main(argc, argv)
int argc;
char **argv;
{
	int useSyslog = 0;
	struct config *cfAddr = NULL;
	int Ncf = 0;
	char *cfstrings = NULL;
	char *file = SOCKD_FC;

	if (argc == 2)
		file = *++argv;
	socks_rdfz(file, &cfAddr, &Ncf, &cfstrings, useSyslog);
	sockd_dumpcf(cfAddr, Ncf, useSyslog);
}
