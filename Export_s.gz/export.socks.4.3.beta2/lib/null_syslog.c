/* null_syslog */

/* null_syslog.c	-	<edwin@cs.ruu.nl>	05/Nov/94
 *	provides empty syslog() functions for those who
 *	would rather not have the rClient programs logging
 *	to the syslog daemon.
 */

/* varargs/stdarg, let's try to unify ANSI/non-ANSI variants here */
#ifdef __STDC__
#include <stdarg.h>
#define VARARGS(func,type,arg) func(type arg, ...)
#define VASTART(ap,type,name)  va_start(ap,name)
#define VAEND(ap)              va_end(ap)
#else
#include <varargs.h>
#define VARARGS(func,type,arg) func(va_alist) va_dcl
#define VASTART(ap,type,name)  {type name; va_start(ap); name = va_arg(ap, type)
#define VAEND(ap)              va_end(ap);}
#endif

socks_0openlog(ident, log_opt, fac)
	char	*ident;
	int	log_opt,
		fac;
{
	/* empty */
}

socks_0closelog()
{
	/* empty */
}

VARARGS(socks_0syslog, int, prio)
{
	va_list ap;

	VASTART(ap, int, prio);
	/* empty */
	VAEND(ap);
}



